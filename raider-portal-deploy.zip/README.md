Deploy notes
- Only the public/ folder is ever served (Vercel: outputDirectory; GitHub Pages: the workflow uploads public/).
- vercel.json, .github and .gitignore sit outside public/, so no URL can reach them.
- Vercel: import the repo, framework "Other", no build command.
- GitHub Pages: Settings > Pages > Source: "GitHub Actions". Use a private repo if your plan allows.
- Never commit secrets. Anything inside public/ is visible to every visitor.
